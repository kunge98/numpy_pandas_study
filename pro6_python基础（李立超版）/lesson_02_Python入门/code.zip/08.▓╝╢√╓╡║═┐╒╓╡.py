# 布尔值（bool）
# 布尔值主要用来做逻辑判断
# 布尔值一共有两个 True 和 False
# True表示真 False表示假
a = True
a = False
# print('a =',a)

# 布尔值实际上也属于整型，True就相当于1，False就相当于0
# print(1 + False)

# None（空值）
# None专门用来表示不存在
b = None
print(b)